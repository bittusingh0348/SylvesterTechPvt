class UsersController < ApplicationController
def main
end

def NewLogin

end

def show
  @user = User.find(params[:id])
end

def Signup
  @user = User.new
end

def logout
   redirect_to '/SylvesterTechPvt/'
end

def edit
    @user = User.find(params[:id])
end

def create
    @user = User.new(user_params)
    if @user.save
	  redirect_to "/users/#{@user.id}"
    else
      redirect_to "/users/Signup"
    end
end

def update
    @user = User.find(params[:id])
    if @user.update_attributes(user_params)
	  redirect_to "/users/#{@user.id}"
    else
      redirect_to "/users/#{@user.id}/edit/"
    end
end

def Logged 
     user = User.find_by(Email: params[:users][:Email])
     if user && (user.Password === params[:users][:Password])
      redirect_to "/users/#{ user.id }"
     else
      redirect_to "/users/Login/"
     end
end

private
	def user_params
	  params.require(:user).permit(:Name, :Email, :DOB, :Status, :Password)
	end
end
