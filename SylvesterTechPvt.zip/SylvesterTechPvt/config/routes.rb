Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  get '/SylvesterTechPvt/' => 'users#main'
  get '/users/Login' => 'users#NewLogin'
  get '/users/Signup' => 'users#Signup'
  get '/users/:id' => 'users#show'
  get '/users/:id/edit/' => 'users#edit'
  get '/users/Logout' => 'users#logout'
  post '/users/' => 'users#create'
  post '/users/Login' => 'users#Logged'
  resources :users
end
